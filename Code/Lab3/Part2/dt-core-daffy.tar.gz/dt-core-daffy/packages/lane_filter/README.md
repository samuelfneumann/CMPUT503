# Package `lane_filter` {#lane_filter}


## `lane_filter_node` {#lane_filter-lane_filter_node}

This package runs the lane filtering during lane control mode. There are two functionalities implemented. The first one is the estimation of the actual position. This position consist of a distance $d$ form the center of the line and an angle $phi$ with respect to the center of the lane. 

