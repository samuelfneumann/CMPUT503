import duckietown_code_utils as dtu


@dtu.unit_test
def f1():
    pass


if __name__ == "__main__":
    dtu.run_tests_for_this_module()
