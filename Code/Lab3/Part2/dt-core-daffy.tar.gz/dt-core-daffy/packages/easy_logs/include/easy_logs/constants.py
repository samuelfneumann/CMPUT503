class EasyLogsConstants:
    CACHE_CLOUD = "EasyLogsDB-logs-cloud"
    CACHE_LOCAL = "EasyLogsDB-logs-local"
